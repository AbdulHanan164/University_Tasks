#!/usr/bin/env python
# coding: utf-8

# In[89]:


from numpy import*
A=array([0,1,2,3,4,5,6,7,8,9])
print("Array A is from integer 1 to 9:",A)


# In[88]:


matrix=random.randint(1,5,(3,3))
print("Array of random integers matrix :\n",matrix)


# In[85]:


matrix1=array([1,2,3])
matrix2=array([4,5,6])
print("Sum of two matrixes are :",matrix1+matrix2)
print("Subtraction of two matrixes are :",matrix1-matrix2)
print("Multiplication of two matrixes are :",matrix1*matrix2)
print("Divison of two matrixes are :",matrix1/matrix2)


# In[84]:


print("Mean of array A is :",mean(A))
print("Standard derviation of array A is :",std(A))
print("Median of array A is :",median(A))


# In[83]:


print('Even indexes are :')
A[::2]


# In[93]:


result = (5 < A) 
print("Boolean Expersion of Array A is :\n",result)


# In[82]:


print("Array before Reshaping :\n",A)
print("Array After Reshaping :")
A.reshape(2,5)


# In[54]:


b=array([10,11,12,13,14,15,16,17,18,19])
print("Vertical Stack:\n",vstack((A,b)))
print("Horizontal Stack:\n",hstack((A,b)))


# In[35]:


B=random.randint(1,5,(3,3))
print("Matrix 1 is:\n",B)
c=random.randint(6,10,(3,3))
print("Matrix 2 is :\n",c)
print("Element wise multiplication of 2 matrix is :\n")
B*c


# In[68]:


A=array([1,2,3,4,5,6,7,8,9,10])
for i in range(len(A)):
    if A[i]==max(A):
        print("Maximum is :",A.max()," at index : ",i)
for i in range(len(A)):
    if A[i]==min(A):        
        print("Minimum is :",A.min(), " at index :",i)


# In[78]:


print("Matrix 1 is:\n",B)
print("Matrix 2 is :\n",c)
print("Sum of two matrix is:\n",B+c)
print("Sum of Rows are:\n",sum(B,axis=0))
print("Sum of columns are :\n",sum(B,axis=1))


# In[146]:


file=loadtxt("historical_stock_prices.csv",dtype=str,delimiter=',')
Array=array(file)
print("Loaded Array is: \n",Array)
print("Closes are  :\n",Array[1:,4])
Vol = Array[1:,5]
high=Array
highest_vol=max(Array[1:,5])
for i in Vol:
    if i==highest_vol:
        print("\nHighest volume is in date :",Array[6,:1],"and Volume is :",highest_vol)


# In[158]:


file=loadtxt("historical_stock_prices.csv",delimiter=',',dtype=str)
print("Loaded Array is: \n",Array)
print("Closes are  :\n",Array[1:,4])
Vol = Array[1:,5]
high=Array
highest_vol=max(Array[1:,5])
for i in Vol:
    if i==highest_vol:
        print("\nHighest volume is in date :",Array[6,:1],"and Volume is :",highest_vol)


# In[154]:


import numpy as np
infor = [[23.5,34.1,34.4], [34.3,23.5,43.2], [24.4,34.4,33.6]]
mean_data = np.mean(infor)
median_data = median(infor)
variance_data = var(infor)
mean_temp = np.mean(infor, axis = 0)
locations = ["Fasilabad", "jauharabad", "Khusab"]
max_temp_loc = locations[argmax(mean_temp)]
min_temp_loc = locations[argmin(mean_temp)]
yearly_variance = np.var(infor, axis = 0)
print("Mean is :" , mean_data)
print("Median is :", median_data)
print("Maximum temperature at location at :", max_temp_loc)
print("Minimum temperature at location at:", min_temp_loc)
print("Yearly variance: at", yearly_variance)


# In[ ]:




